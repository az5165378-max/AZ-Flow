package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.CustomerRecord
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("AZ Flow", appName)
    }

    @Test
    fun `verify customer profit calculation`() {
        val record = CustomerRecord(
            name = "علی احمد",
            amount = 3000.0,
            fee = 800.0,
            profit = 2200.0,
            status = CustomerRecord.STATUS_COMPLETED
        )
        assertEquals(2200.0, record.amount - record.fee, 0.001)
        assertTrue(record.profit > 0)
    }
}
