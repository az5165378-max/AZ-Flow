package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.CustomerRecord
import com.example.data.CustomerRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class ScreenTab {
    HOME,
    RECORDS,
    ANALYTICS,
    SETTINGS
}

enum class SortOption {
    NEWEST,
    HIGHEST_PROFIT,
    NAME_AZ
}

data class UiSummary(
    val totalCollected: Double = 0.0,
    val totalProfit: Double = 0.0,
    val totalFee: Double = 0.0,
    val totalCount: Int = 0,
    val completedCount: Int = 0,
    val pendingCount: Int = 0,
    val marginPercentage: Double = 0.0
)

class AZFlowViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: CustomerRepository

    init {
        val db = AppDatabase.getDatabase(application)
        repository = CustomerRepository(db.customerRecordDao())
    }

    // Splash State
    private val _showSplash = MutableStateFlow(true)
    val showSplash: StateFlow<Boolean> = _showSplash.asStateFlow()

    fun dismissSplash() {
        _showSplash.value = false
    }

    // Navigation State
    private val _currentTab = MutableStateFlow(ScreenTab.HOME)
    val currentTab: StateFlow<ScreenTab> = _currentTab.asStateFlow()

    fun setTab(tab: ScreenTab) {
        _currentTab.value = tab
    }

    // Records Flow
    val allRecordsFlow: StateFlow<List<CustomerRecord>> = repository.allRecords
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Search and Filter State
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedStatusFilter = MutableStateFlow("سب")
    val selectedStatusFilter: StateFlow<String> = _selectedStatusFilter.asStateFlow()

    private val _sortOption = MutableStateFlow(SortOption.NEWEST)
    val sortOption: StateFlow<SortOption> = _sortOption.asStateFlow()

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setStatusFilter(filter: String) {
        _selectedStatusFilter.value = filter
    }

    fun setSortOption(option: SortOption) {
        _sortOption.value = option
    }

    // Filtered Records
    val filteredRecords: StateFlow<List<CustomerRecord>> = combine(
        allRecordsFlow,
        _searchQuery,
        _selectedStatusFilter,
        _sortOption
    ) { records, query, filter, sort ->
        var list = records

        if (query.isNotBlank()) {
            val q = query.trim().lowercase(Locale.getDefault())
            list = list.filter {
                it.name.lowercase(Locale.getDefault()).contains(q) ||
                        it.work.lowercase(Locale.getDefault()).contains(q) ||
                        it.phone1.contains(q) ||
                        it.phone2.contains(q) ||
                        it.phone3.contains(q)
            }
        }

        if (filter != "سب") {
            list = list.filter { it.status == filter }
        }

        when (sort) {
            SortOption.NEWEST -> list.sortedByDescending { it.createdAt }
            SortOption.HIGHEST_PROFIT -> list.sortedByDescending { it.profit }
            SortOption.NAME_AZ -> list.sortedBy { it.name }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Summary calculation
    val summary: StateFlow<UiSummary> = allRecordsFlow.combine(allRecordsFlow) { records, _ ->
        var totalCollected = 0.0
        var totalProfit = 0.0
        var totalFee = 0.0
        var completed = 0
        var pending = 0

        records.forEach { record ->
            totalCollected += record.amount
            totalProfit += record.profit
            totalFee += record.fee
            if (record.status == CustomerRecord.STATUS_COMPLETED) {
                completed++
            } else {
                pending++
            }
        }

        val margin = if (totalCollected > 0) (totalProfit / totalCollected) * 100 else 0.0
        UiSummary(
            totalCollected = totalCollected,
            totalProfit = totalProfit,
            totalFee = totalFee,
            totalCount = records.size,
            completedCount = completed,
            pendingCount = pending,
            marginPercentage = margin
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UiSummary())

    // Form State
    var editingId: Long? = null
        private set

    val formName = MutableStateFlow("")
    val formPhone1 = MutableStateFlow("")
    val formPhone2 = MutableStateFlow("")
    val formPhone3 = MutableStateFlow("")
    val formWork = MutableStateFlow("")
    val formAmount = MutableStateFlow("")
    val formFee = MutableStateFlow("")
    val formStatus = MutableStateFlow(CustomerRecord.STATUS_COMPLETED)

    // Snackbar event
    private val _userMessage = MutableSharedFlow<String>()
    val userMessage: SharedFlow<String> = _userMessage.asSharedFlow()

    fun resetForm() {
        editingId = null
        formName.value = ""
        formPhone1.value = ""
        formPhone2.value = ""
        formPhone3.value = ""
        formWork.value = ""
        formAmount.value = ""
        formFee.value = ""
        formStatus.value = CustomerRecord.STATUS_COMPLETED
    }

    fun startEdit(record: CustomerRecord) {
        editingId = record.id
        formName.value = record.name
        formPhone1.value = record.phone1
        formPhone2.value = record.phone2
        formPhone3.value = record.phone3
        formWork.value = record.work
        formAmount.value = if (record.amount > 0) record.amount.toInt().toString() else ""
        formFee.value = if (record.fee > 0) record.fee.toInt().toString() else "0"
        formStatus.value = record.status
        _currentTab.value = ScreenTab.HOME
    }

    fun applyWorkPreset(preset: String) {
        val current = formWork.value.trim()
        formWork.value = if (current.isEmpty()) preset else "$current, $preset"
    }

    fun saveRecord(onSuccess: () -> Unit) {
        val name = formName.value.trim()
        if (name.isBlank()) {
            viewModelScope.launch { _userMessage.emit("براہ کرم گاہک کا نام درج کریں!") }
            return
        }

        val amount = formAmount.value.toDoubleOrNull() ?: 0.0
        if (amount <= 0.0) {
            viewModelScope.launch { _userMessage.emit("براہ کرم وصولی کی درست رقم درج کریں!") }
            return
        }

        val fee = formFee.value.toDoubleOrNull() ?: 0.0
        val profit = amount - fee
        val todayStr = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())

        viewModelScope.launch {
            if (editingId != null) {
                val updated = CustomerRecord(
                    id = editingId!!,
                    name = name,
                    phone1 = formPhone1.value.trim(),
                    phone2 = formPhone2.value.trim(),
                    phone3 = formPhone3.value.trim(),
                    work = formWork.value.trim(),
                    amount = amount,
                    fee = fee,
                    profit = profit,
                    status = formStatus.value,
                    date = todayStr,
                    updatedAt = System.currentTimeMillis()
                )
                repository.update(updated)
                _userMessage.emit("ریکارڈ کامیابی سے تبدیل ہو گیا!")
            } else {
                val newRecord = CustomerRecord(
                    name = name,
                    phone1 = formPhone1.value.trim(),
                    phone2 = formPhone2.value.trim(),
                    phone3 = formPhone3.value.trim(),
                    work = formWork.value.trim(),
                    amount = amount,
                    fee = fee,
                    profit = profit,
                    status = formStatus.value,
                    date = todayStr,
                    createdAt = System.currentTimeMillis()
                )
                repository.insert(newRecord)
                _userMessage.emit("نیا ریکارڈ محفوظ ہو گیا!")
            }
            resetForm()
            onSuccess()
        }
    }

    fun deleteRecord(record: CustomerRecord) {
        viewModelScope.launch {
            repository.delete(record)
            _userMessage.emit("${record.name} کا ریکارڈ ڈیلیٹ کر دیا گیا")
        }
    }

    fun clearAllData() {
        viewModelScope.launch {
            repository.clearAll()
            _userMessage.emit("تمام ڈیٹا کامیابی سے ڈیلیٹ کر دیا گیا!")
        }
    }

    fun loadSampleData() {
        viewModelScope.launch {
            repository.loadSampleDemoData()
            _userMessage.emit("ڈیمو ڈیٹا کامیابی سے لوڈ ہو گیا!")
        }
    }

    fun getExportJson(): String {
        return repository.exportToJson(allRecordsFlow.value)
    }

    fun restoreFromJson(jsonString: String) {
        viewModelScope.launch {
            val result = repository.importFromJson(jsonString)
            result.onSuccess { count ->
                _userMessage.emit("$count کسٹمر ریکارڈز کامیابی سے بحال (Restore) ہو گئے!")
            }.onFailure { err ->
                _userMessage.emit("فائل پڑھنے میں مسئلہ: ${err.localizedMessage}")
            }
        }
    }
}
