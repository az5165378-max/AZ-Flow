package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val AzNavyDark = Color(0xFF06152E)
val AzNavySurface = Color(0xFF0F2347)
val AzNavyCard = Color(0xFF132B54)
val AzPrimary = Color(0xFF0284C7)
val AzPrimaryLight = Color(0xFF38BDF8)
val AzCyanGlow = Color(0xFF00D9FF)
val AzProfit = Color(0xFF059669)
val AzProfitLight = Color(0xFFD1FAE5)
val AzExpense = Color(0xFFE11D48)
val AzExpenseLight = Color(0xFFFFE4E6)
val AzPending = Color(0xFFD97706)
val AzPendingLight = Color(0xFFFEF3C7)
val AzWhatsApp = Color(0xFF16A34A)
val AzBackgroundLight = Color(0xFFF1F5F9)
val AzSurfaceLight = Color(0xFFFFFFFF)
val AzBorderLight = Color(0xFFCBD5E1)
val AzTextDark = Color(0xFF0F172A)
val AzTextMuted = Color(0xFF64748B)
