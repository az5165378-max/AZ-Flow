package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BusinessCenter
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CustomerRecord
import com.example.ui.AZFlowViewModel
import com.example.ui.ScreenTab
import com.example.ui.SortOption
import com.example.ui.components.CustomerReceiptDialog
import com.example.ui.components.formatNumber
import com.example.ui.components.shareOnWhatsApp
import com.example.ui.theme.AzExpense
import com.example.ui.theme.AzPending
import com.example.ui.theme.AzPrimary
import com.example.ui.theme.AzPrimaryLight
import com.example.ui.theme.AzProfit
import com.example.ui.theme.AzWhatsApp

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RecordsScreen(
    viewModel: AZFlowViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val records by viewModel.filteredRecords.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedFilter by viewModel.selectedStatusFilter.collectAsState()
    val sortOption by viewModel.sortOption.collectAsState()

    var recordToDelete by remember { mutableStateOf<CustomerRecord?>(null) }
    var selectedReceiptRecord by remember { mutableStateOf<CustomerRecord?>(null) }
    var showSortMenu by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Section Title & Counter
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "👥 تمام گاہکوں کا ریکارڈ",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = AzPrimary
                )
                Text(
                    text = "کل موجود اندراجات: ${records.size}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Sort Dropdown Button
            Box {
                OutlinedButton(
                    onClick = { showSortMenu = true },
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("sort_menu_button")
                ) {
                    Icon(imageVector = Icons.Default.Sort, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = when (sortOption) {
                            SortOption.NEWEST -> "نیا ریکارڈ"
                            SortOption.HIGHEST_PROFIT -> "منافع"
                            SortOption.NAME_AZ -> "نام"
                        },
                        fontSize = 12.sp
                    )
                }

                DropdownMenu(
                    expanded = showSortMenu,
                    onDismissRequest = { showSortMenu = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("📅 نیا ریکارڈ پہلے (Newest)") },
                        onClick = {
                            viewModel.setSortOption(SortOption.NEWEST)
                            showSortMenu = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("💰 زیادہ منافع پہلے (Highest Profit)") },
                        onClick = {
                            viewModel.setSortOption(SortOption.HIGHEST_PROFIT)
                            showSortMenu = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("🔤 نام کے مطابق (Name A-Z)") },
                        onClick = {
                            viewModel.setSortOption(SortOption.NAME_AZ)
                            showSortMenu = false
                        }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Search Input
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.updateSearchQuery(it) },
            placeholder = { Text("🔍 نام، کام یا موبائل نمبر سے تلاش کریں...") },
            leadingIcon = {
                Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = AzPrimary)
            },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                        Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear")
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("records_search_input"),
            shape = RoundedCornerShape(12.dp),
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = AzPrimary,
                unfocusedBorderColor = MaterialTheme.colorScheme.outline
            )
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Filter Chips Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = selectedFilter == "سب",
                onClick = { viewModel.setStatusFilter("سب") },
                label = { Text("سب (All)") },
                modifier = Modifier.testTag("filter_all_chip")
            )

            FilterChip(
                selected = selectedFilter == CustomerRecord.STATUS_COMPLETED,
                onClick = { viewModel.setStatusFilter(CustomerRecord.STATUS_COMPLETED) },
                label = { Text("✅ مکمل") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = Color(0xFFD1FAE5),
                    selectedLabelColor = Color(0xFF065F46)
                ),
                modifier = Modifier.testTag("filter_completed_chip")
            )

            FilterChip(
                selected = selectedFilter == CustomerRecord.STATUS_IN_PROGRESS,
                onClick = { viewModel.setStatusFilter(CustomerRecord.STATUS_IN_PROGRESS) },
                label = { Text("⏳ جاری ہے") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = Color(0xFFFEF3C7),
                    selectedLabelColor = Color(0xFF92400E)
                ),
                modifier = Modifier.testTag("filter_pending_chip")
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // List or Empty View
        if (records.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.FolderOpen,
                        contentDescription = null,
                        modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = if (searchQuery.isNotEmpty()) "کوئی مماثل ریکارڈ نہیں ملا" else "📂 کوئی ریکارڈ موجود نہیں ہے",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    if (searchQuery.isEmpty()) {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = { viewModel.setTab(ScreenTab.HOME) },
                                colors = ButtonDefaults.buttonColors(containerColor = AzPrimary)
                            ) {
                                Icon(imageVector = Icons.Default.Add, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("نیا اندراج کریں")
                            }

                            OutlinedButton(
                                onClick = { viewModel.loadSampleData() }
                            ) {
                                Text("ڈیمو ڈیٹا لوڈ کریں")
                            }
                        }
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(records, key = { it.id }) { record ->
                    CustomerCard(
                        record = record,
                        onEdit = { viewModel.startEdit(record) },
                        onDelete = { recordToDelete = record },
                        onOpenReceipt = { selectedReceiptRecord = record },
                        onCall = { phone ->
                            val intent = Intent(Intent.ACTION_DIAL).apply {
                                data = Uri.parse("tel:$phone")
                            }
                            context.startActivity(intent)
                        },
                        onWhatsApp = { phone ->
                            val msg = "محترم ${record.name} صاحب، آپ کا کام: ${record.work}۔ کل بل: Rs. ${formatNumber(record.amount)}۔ شکریہ!"
                            shareOnWhatsApp(context, phone, msg)
                        }
                    )
                }
                item {
                    Spacer(modifier = Modifier.height(60.dp))
                }
            }
        }
    }

    // Delete Confirmation Dialog
    recordToDelete?.let { record ->
        AlertDialog(
            onDismissRequest = { recordToDelete = null },
            title = {
                Text(
                    text = "⚠️ ریکارڈ ڈیلیٹ کی تصدیق",
                    fontWeight = FontWeight.Bold,
                    color = AzExpense
                )
            },
            text = {
                Text("کیا آپ واقعی ${record.name} کا ریکارڈ ہمیشہ کے لیے ڈیلیٹ کرنا چاہتے ہیں؟")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteRecord(record)
                        recordToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AzExpense),
                    modifier = Modifier.testTag("confirm_delete_record_button")
                ) {
                    Text("ہاں، ڈیلیٹ کریں")
                }
            },
            dismissButton = {
                TextButton(onClick = { recordToDelete = null }) {
                    Text("کینسل")
                }
            }
        )
    }

    // Customer Digital Receipt Dialog
    selectedReceiptRecord?.let { record ->
        CustomerReceiptDialog(
            record = record,
            onDismiss = { selectedReceiptRecord = null }
        )
    }
}

@Composable
fun CustomerCard(
    record: CustomerRecord,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onOpenReceipt: () -> Unit,
    onCall: (String) -> Unit,
    onWhatsApp: (String) -> Unit
) {
    val isCompleted = record.status == CustomerRecord.STATUS_COMPLETED
    val initial = record.name.trim().firstOrNull()?.toString() ?: "A"

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onOpenReceipt() }
            .testTag("customer_item_card_${record.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            // Header: Avatar, Name, Status, Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    // Avatar Circle
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(if (isCompleted) Color(0xFFD1FAE5) else Color(0xFFFEF3C7)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = initial,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = if (isCompleted) AzProfit else AzPending
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(
                            text = record.name,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        // Phone list
                        val phones = listOf(record.phone1, record.phone2, record.phone3)
                            .filter { it.isNotBlank() }
                        if (phones.isNotEmpty()) {
                            Text(
                                text = phones.joinToString(" • "),
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                // Status Badge
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (isCompleted) Color(0xFFD1FAE5) else Color(0xFFFEF3C7),
                    modifier = Modifier.padding(start = 6.dp)
                ) {
                    Text(
                        text = record.status,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isCompleted) Color(0xFF065F46) else Color(0xFF92400E),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Work Description
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.BusinessCenter,
                    contentDescription = null,
                    tint = AzPrimary,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = record.work.ifBlank { "کام کی تفصیل درج نہیں" },
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Financial Slip Row (وصولی | فیس | منافع)
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "وصولی: Rs. ${formatNumber(record.amount)}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "|",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.outline
                        )
                        Text(
                            text = "لاگت: Rs. ${formatNumber(record.fee)}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = AzExpense
                        )
                    }

                    Text(
                        text = "منافع: Rs. ${formatNumber(record.profit)}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black,
                        color = AzProfit
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Date & Action Buttons Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "📅 ${record.date}",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    // Call Button
                    if (record.phone1.isNotBlank()) {
                        IconButton(
                            onClick = { onCall(record.phone1) },
                            modifier = Modifier.size(30.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Phone,
                                contentDescription = "Call",
                                tint = AzPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    // WhatsApp Button
                    if (record.phone1.isNotBlank()) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFFDCFCE7),
                            modifier = Modifier
                                .size(30.dp)
                                .clip(CircleShape)
                                .clickable { onWhatsApp(record.phone1) }
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = "💬",
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }

                    // Receipt Slip Button
                    IconButton(
                        onClick = onOpenReceipt,
                        modifier = Modifier.size(30.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Receipt,
                            contentDescription = "Receipt",
                            tint = Color(0xFF475569),
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    // Edit Button
                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier
                            .size(30.dp)
                            .testTag("edit_record_button_${record.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit",
                            tint = AzPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    // Delete Button
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier
                            .size(30.dp)
                            .testTag("delete_record_button_${record.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete",
                            tint = AzExpense,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}
