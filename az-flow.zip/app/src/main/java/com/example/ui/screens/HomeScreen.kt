package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BusinessCenter
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CustomerRecord
import com.example.ui.AZFlowViewModel
import com.example.ui.ScreenTab
import com.example.ui.components.formatNumber
import com.example.ui.theme.AzExpense
import com.example.ui.theme.AzNavyDark
import com.example.ui.theme.AzNavySurface
import com.example.ui.theme.AzPending
import com.example.ui.theme.AzPrimary
import com.example.ui.theme.AzPrimaryLight
import com.example.ui.theme.AzProfit

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeScreen(
    viewModel: AZFlowViewModel,
    modifier: Modifier = Modifier
) {
    val name by viewModel.formName.collectAsState()
    val phone1 by viewModel.formPhone1.collectAsState()
    val phone2 by viewModel.formPhone2.collectAsState()
    val phone3 by viewModel.formPhone3.collectAsState()
    val work by viewModel.formWork.collectAsState()
    val amount by viewModel.formAmount.collectAsState()
    val fee by viewModel.formFee.collectAsState()
    val status by viewModel.formStatus.collectAsState()
    val isEditing = viewModel.editingId != null

    val recentRecords by viewModel.allRecordsFlow.collectAsState()

    val amountVal = amount.toDoubleOrNull() ?: 0.0
    val feeVal = fee.toDoubleOrNull() ?: 0.0
    val calculatedProfit = amountVal - feeVal

    val scrollState = rememberScrollState()

    val servicePresets = listOf(
        "آن لائن فارم",
        "پاسپورٹ چالان",
        "ڈیزائننگ",
        "فوٹو شوٹ",
        "پرنٹنگ و فوٹو کاپی",
        "شناختی کارڈ تجدید",
        "کھاتہ بل",
        "ٹیکس ریٹرن"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Form Title Card
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (isEditing) Icons.Default.Edit else Icons.Default.Add,
                    contentDescription = null,
                    tint = AzPrimary,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isEditing) "ریکارڈ ایڈٹ کریں (Update)" else "نیا گاہک درج کریں (New Entry)",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = AzPrimary
                )
            }

            if (isEditing) {
                OutlinedButton(
                    onClick = { viewModel.resetForm() },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = AzExpense),
                    modifier = Modifier.testTag("cancel_edit_button")
                ) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("کینسل")
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Card Container for Form
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                // Customer Name
                Text(
                    text = "گاہک کا نام (Customer Name) *",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = name,
                    onValueChange = { viewModel.formName.value = it },
                    placeholder = { Text("نام درج کریں (مثلاً: محمد احمد)") },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = AzPrimary)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("cust_name_input"),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AzPrimary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    )
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Mobile Numbers
                Text(
                    text = "موبائل فون نمبرز (Phone Numbers)",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(4.dp))

                // Responsive Phone Rows
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = phone1,
                        onValueChange = { viewModel.formPhone1.value = it },
                        placeholder = { Text("نمبر 1") },
                        label = { Text("موبائل 1") },
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.Phone, contentDescription = null, tint = AzPrimary, modifier = Modifier.size(18.dp))
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("cust_phone1_input"),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = phone2,
                        onValueChange = { viewModel.formPhone2.value = it },
                        placeholder = { Text("نمبر 2") },
                        label = { Text("موبائل 2") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("cust_phone2_input"),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = phone3,
                    onValueChange = { viewModel.formPhone3.value = it },
                    placeholder = { Text("اختیاری تیسرا نمبر (Optional)") },
                    label = { Text("موبائل 3 (اختیاری)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("cust_phone3_input"),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Work Description
                Text(
                    text = "کام کی تفصیل (Service / Work Description) *",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = work,
                    onValueChange = { viewModel.formWork.value = it },
                    placeholder = { Text("مثلاً: آن لائن فارم / فوٹو شوٹ / ڈیزائننگ") },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.BusinessCenter, contentDescription = null, tint = AzPrimary)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("cust_work_input"),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AzPrimary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Quick Service Preset Chips
                Text(
                    text = "تیز ترین انتخاب (Quick Presets):",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(4.dp))
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    servicePresets.forEach { preset ->
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .clickable { viewModel.applyWorkPreset(preset) }
                        ) {
                            Text(
                                text = "+ $preset",
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Amount and Fee
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Amount
                    OutlinedTextField(
                        value = amount,
                        onValueChange = { viewModel.formAmount.value = it },
                        placeholder = { Text("0") },
                        label = { Text("وصولی رقم (Rs.) *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("cust_amount_input"),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AzPrimary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline
                        )
                    )

                    // Fee
                    OutlinedTextField(
                        value = fee,
                        onValueChange = { viewModel.formFee.value = it },
                        placeholder = { Text("0") },
                        label = { Text("فیس / لاگت (Rs.)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("cust_fee_input"),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AzExpense,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Real-time Calculated Profit Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (calculatedProfit >= 0) Color(0xFFECFDF5) else Color(0xFFFFF1F2)
                    ),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = Brush.horizontalGradient(
                            listOf(
                                if (calculatedProfit >= 0) AzProfit.copy(alpha = 0.5f) else AzExpense.copy(alpha = 0.5f),
                                Color.Transparent
                            )
                        )
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "حساب شدہ منافع (Calculated Profit):",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = if (calculatedProfit >= 0) Color(0xFF065F46) else Color(0xFF9F1239)
                            )
                            Text(
                                text = "وصولی Rs. ${formatNumber(amountVal)} - لاگت Rs. ${formatNumber(feeVal)}",
                                fontSize = 10.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                        Text(
                            text = "Rs. ${formatNumber(calculatedProfit)}",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            color = if (calculatedProfit >= 0) AzProfit else AzExpense
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Work Status Selector
                Text(
                    text = "کام کی حالت (Work Status):",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = status == CustomerRecord.STATUS_COMPLETED,
                        onClick = { viewModel.formStatus.value = CustomerRecord.STATUS_COMPLETED },
                        label = { Text("✅ مکمل ہو گیا (Done)") },
                        leadingIcon = if (status == CustomerRecord.STATUS_COMPLETED) {
                            { Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp)) }
                        } else null,
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFFD1FAE5),
                            selectedLabelColor = Color(0xFF065F46)
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("status_completed_chip")
                    )

                    FilterChip(
                        selected = status == CustomerRecord.STATUS_IN_PROGRESS,
                        onClick = { viewModel.formStatus.value = CustomerRecord.STATUS_IN_PROGRESS },
                        label = { Text("⏳ جاری ہے (Pending)") },
                        leadingIcon = if (status == CustomerRecord.STATUS_IN_PROGRESS) {
                            { Icon(Icons.Default.HourglassTop, contentDescription = null, modifier = Modifier.size(16.dp)) }
                        } else null,
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFFFEF3C7),
                            selectedLabelColor = Color(0xFF92400E)
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("status_pending_chip")
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Save / Update Button
                Button(
                    onClick = {
                        viewModel.saveRecord {
                            viewModel.setTab(ScreenTab.RECORDS)
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("save_customer_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AzPrimary)
                ) {
                    Icon(
                        imageVector = if (isEditing) Icons.Default.Edit else Icons.Default.Save,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isEditing) "تبدیلی محفوظ کریں (Update Record)" else "ریکارڈ محفوظ کریں (Save Record)",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Recent Records Preview
        if (recentRecords.isNotEmpty()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "حالیہ اندراجات (Recent Entries)",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "سب دیکھیں ➔",
                    color = AzPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .clickable { viewModel.setTab(ScreenTab.RECORDS) }
                        .padding(4.dp)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            recentRecords.take(3).forEach { record ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable { viewModel.setTab(ScreenTab.RECORDS) },
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = record.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(
                                text = record.work.ifEmpty { "کام مقرر نہیں" },
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "Rs. ${formatNumber(record.profit)}",
                                fontWeight = FontWeight.Bold,
                                color = AzProfit,
                                fontSize = 13.sp
                            )
                            Text(
                                text = record.status,
                                fontSize = 10.sp,
                                color = if (record.status == CustomerRecord.STATUS_COMPLETED) AzProfit else AzPending
                            )
                        }
                    }
                }
            }
        }
    }
}
