package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.CustomerRecord
import com.example.ui.theme.AzExpense
import com.example.ui.theme.AzNavyDark
import com.example.ui.theme.AzPrimary
import com.example.ui.theme.AzProfit
import com.example.ui.theme.AzWhatsApp

@Composable
fun CustomerReceiptDialog(
    record: CustomerRecord,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // Header Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "AZ Flow",
                                fontWeight = FontWeight.Black,
                                fontSize = 18.sp,
                                color = AzPrimary
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "⚡", fontSize = 16.sp)
                        }
                        Text(
                            text = "کسٹمر رسید / انوائس سِلپ",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                // Customer Info
                Text(
                    text = "گاہک کی تفصیلات (Customer Details):",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "👤 ${record.name}",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                if (record.phone1.isNotBlank() || record.phone2.isNotBlank()) {
                    val phones = listOf(record.phone1, record.phone2, record.phone3)
                        .filter { it.isNotBlank() }
                        .joinToString(" , ")
                    Text(
                        text = "📞 $phones",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Work
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "🛠️ کام کی تفصیل:",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = record.work.ifBlank { "مقرر نہیں" },
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Financial Breakdown Slip
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                    border = CardDefaults.outlinedCardBorder()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("کل بل / وصولی:", fontSize = 12.sp, color = Color(0xFF475569))
                            Text("Rs. ${formatNumber(record.amount)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AzPrimary)
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("فیس / لاگت (Cost):", fontSize = 12.sp, color = Color(0xFF475569))
                            Text("Rs. ${formatNumber(record.fee)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AzExpense)
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("خالص منافع (Net Profit):", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                            Text("Rs. ${formatNumber(record.profit)}", fontSize = 15.sp, fontWeight = FontWeight.Black, color = AzProfit)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Date and Status
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "تاریخ: ${record.date}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "حالت: ${record.status}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (record.status == CustomerRecord.STATUS_COMPLETED) AzProfit else Color(0xFFD97706)
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Actions: WhatsApp share & Call
                Button(
                    onClick = {
                        val text = generateReceiptText(record)
                        shareOnWhatsApp(context, record.phone1, text)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AzWhatsApp)
                ) {
                    Text(
                        text = "💬 WhatsApp پر رسید بھیجیں",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            val text = generateReceiptText(record)
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_SUBJECT, "AZ Flow Receipt - ${record.name}")
                                putExtra(Intent.EXTRA_TEXT, text)
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "رسید شیئر کریں"))
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("شیئر سلپ", fontSize = 11.sp)
                    }

                    if (record.phone1.isNotBlank()) {
                        OutlinedButton(
                            onClick = {
                                val intent = Intent(Intent.ACTION_DIAL).apply {
                                    data = Uri.parse("tel:${record.phone1}")
                                }
                                context.startActivity(intent)
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("کال کریں", fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

fun generateReceiptText(record: CustomerRecord): String {
    return """
        📄 *AZ Flow - کسٹمر رسید* ⚡
        ----------------------------------
        👤 *گاہک کا نام:* ${record.name}
        🛠️ *کام کی تفصیل:* ${record.work}
        💰 *کل رقم:* Rs. ${formatNumber(record.amount)}
        📌 *حالت:* ${record.status}
        📅 *تاریخ:* ${record.date}
        ----------------------------------
        شکریہ! Ansar AZ (AZ Flow)
        رابطہ: 03298191689
    """.trimIndent()
}

fun shareOnWhatsApp(context: Context, phone: String, message: String) {
    val cleanPhone = phone.replace(Regex("[^0-9]"), "")
    val formattedPhone = when {
        cleanPhone.startsWith("03") -> "92${cleanPhone.substring(1)}"
        cleanPhone.startsWith("92") -> cleanPhone
        else -> cleanPhone
    }

    val url = if (formattedPhone.isNotBlank()) {
        "https://wa.me/$formattedPhone?text=${Uri.encode(message)}"
    } else {
        "https://wa.me/?text=${Uri.encode(message)}"
    }

    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
    context.startActivity(intent)
}
