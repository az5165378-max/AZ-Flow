package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = AzPrimaryLight,
    onPrimary = AzNavyDark,
    primaryContainer = AzNavySurface,
    onPrimaryContainer = AzPrimaryLight,
    secondary = AzCyanGlow,
    onSecondary = AzNavyDark,
    background = AzNavyDark,
    onBackground = Color(0xFFF8FAFC),
    surface = AzNavySurface,
    onSurface = Color(0xFFF8FAFC),
    surfaceVariant = AzNavyCard,
    onSurfaceVariant = Color(0xFFCBD5E1),
    error = AzExpense,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = AzPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE0F2FE),
    onPrimaryContainer = Color(0xFF0369A1),
    secondary = AzPrimaryLight,
    onSecondary = Color.White,
    background = AzBackgroundLight,
    onBackground = AzTextDark,
    surface = AzSurfaceLight,
    onSurface = AzTextDark,
    surfaceVariant = Color(0xFFF8FAFC),
    onSurfaceVariant = AzTextMuted,
    outline = AzBorderLight,
    error = AzExpense,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Set to false to keep signature AZ Flow branding consistent
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
