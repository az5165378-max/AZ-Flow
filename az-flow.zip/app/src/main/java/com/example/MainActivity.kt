package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Insights
import androidx.compose.material.icons.outlined.People
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.AZFlowViewModel
import com.example.ui.ScreenTab
import com.example.ui.components.AppHeader
import com.example.ui.components.SplashScreenView
import com.example.ui.screens.AnalyticsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.RecordsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.AzNavyDark
import com.example.ui.theme.AzPrimary
import com.example.ui.theme.AzPrimaryLight
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                AZFlowMainApp()
            }
        }
    }
}

@Composable
fun AZFlowMainApp(viewModel: AZFlowViewModel = viewModel()) {
    val showSplash by viewModel.showSplash.collectAsState()
    val currentTab by viewModel.currentTab.collectAsState()
    val summary by viewModel.summary.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        viewModel.userMessage.collect { message ->
            snackbarHostState.showSnackbar(message)
        }
    }

    // Handle back button when inside non-Home tabs
    BackHandler(enabled = currentTab != ScreenTab.HOME) {
        viewModel.setTab(ScreenTab.HOME)
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            topBar = {
                AppHeader(
                    summary = summary,
                    modifier = Modifier.statusBarsPadding()
                )
            },
            bottomBar = {
                NavigationBar(
                    containerColor = AzNavyDark,
                    contentColor = Color.White,
                    tonalElevation = 8.dp
                ) {
                    // Tab 1: Home
                    NavigationBarItem(
                        selected = currentTab == ScreenTab.HOME,
                        onClick = { viewModel.setTab(ScreenTab.HOME) },
                        icon = {
                            Icon(
                                imageVector = if (currentTab == ScreenTab.HOME) Icons.Filled.Home else Icons.Outlined.Home,
                                contentDescription = "ہوم"
                            )
                        },
                        label = {
                            Text(
                                text = "ہوم",
                                fontSize = 11.sp,
                                fontWeight = if (currentTab == ScreenTab.HOME) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = AzNavyDark,
                            selectedTextColor = AzPrimaryLight,
                            indicatorColor = AzPrimaryLight,
                            unselectedIconColor = Color(0xFF94A3B8),
                            unselectedTextColor = Color(0xFF94A3B8)
                        ),
                        modifier = Modifier.testTag("nav_home")
                    )

                    // Tab 2: Records
                    NavigationBarItem(
                        selected = currentTab == ScreenTab.RECORDS,
                        onClick = { viewModel.setTab(ScreenTab.RECORDS) },
                        icon = {
                            Icon(
                                imageVector = if (currentTab == ScreenTab.RECORDS) Icons.Filled.People else Icons.Outlined.People,
                                contentDescription = "تمام ریکارڈ"
                            )
                        },
                        label = {
                            Text(
                                text = "تمام ریکارڈ",
                                fontSize = 11.sp,
                                fontWeight = if (currentTab == ScreenTab.RECORDS) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = AzNavyDark,
                            selectedTextColor = AzPrimaryLight,
                            indicatorColor = AzPrimaryLight,
                            unselectedIconColor = Color(0xFF94A3B8),
                            unselectedTextColor = Color(0xFF94A3B8)
                        ),
                        modifier = Modifier.testTag("nav_records")
                    )

                    // Tab 3: Analytics
                    NavigationBarItem(
                        selected = currentTab == ScreenTab.ANALYTICS,
                        onClick = { viewModel.setTab(ScreenTab.ANALYTICS) },
                        icon = {
                            Icon(
                                imageVector = if (currentTab == ScreenTab.ANALYTICS) Icons.Filled.Insights else Icons.Outlined.Insights,
                                contentDescription = "تجزیہ و منافع"
                            )
                        },
                        label = {
                            Text(
                                text = "تجزیہ",
                                fontSize = 11.sp,
                                fontWeight = if (currentTab == ScreenTab.ANALYTICS) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = AzNavyDark,
                            selectedTextColor = AzPrimaryLight,
                            indicatorColor = AzPrimaryLight,
                            unselectedIconColor = Color(0xFF94A3B8),
                            unselectedTextColor = Color(0xFF94A3B8)
                        ),
                        modifier = Modifier.testTag("nav_analytics")
                    )

                    // Tab 4: Settings
                    NavigationBarItem(
                        selected = currentTab == ScreenTab.SETTINGS,
                        onClick = { viewModel.setTab(ScreenTab.SETTINGS) },
                        icon = {
                            Icon(
                                imageVector = if (currentTab == ScreenTab.SETTINGS) Icons.Filled.Settings else Icons.Outlined.Settings,
                                contentDescription = "سیٹنگز"
                            )
                        },
                        label = {
                            Text(
                                text = "سیٹنگز",
                                fontSize = 11.sp,
                                fontWeight = if (currentTab == ScreenTab.SETTINGS) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = AzNavyDark,
                            selectedTextColor = AzPrimaryLight,
                            indicatorColor = AzPrimaryLight,
                            unselectedIconColor = Color(0xFF94A3B8),
                            unselectedTextColor = Color(0xFF94A3B8)
                        ),
                        modifier = Modifier.testTag("nav_settings")
                    )
                }
            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                AnimatedContent(
                    targetState = currentTab,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "TabContentTransition"
                ) { targetTab ->
                    when (targetTab) {
                        ScreenTab.HOME -> HomeScreen(viewModel = viewModel)
                        ScreenTab.RECORDS -> RecordsScreen(viewModel = viewModel)
                        ScreenTab.ANALYTICS -> AnalyticsScreen(viewModel = viewModel)
                        ScreenTab.SETTINGS -> SettingsScreen(viewModel = viewModel)
                    }
                }
            }
        }

        // Animated Splash Screen overlay on first launch
        AnimatedVisibility(
            visible = showSplash,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            SplashScreenView(
                onFinished = { viewModel.dismissSplash() }
            )
        }
    }
}
