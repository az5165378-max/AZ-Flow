package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CustomerRecordDao {
    @Query("SELECT * FROM customer_records ORDER BY createdAt DESC")
    fun getAllRecords(): Flow<List<CustomerRecord>>

    @Query("SELECT * FROM customer_records WHERE id = :id LIMIT 1")
    suspend fun getRecordById(id: Long): CustomerRecord?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecord(record: CustomerRecord): Long

    @Update
    suspend fun updateRecord(record: CustomerRecord)

    @Delete
    suspend fun deleteRecord(record: CustomerRecord)

    @Query("DELETE FROM customer_records WHERE id = :id")
    suspend fun deleteRecordById(id: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(records: List<CustomerRecord>)

    @Query("DELETE FROM customer_records")
    suspend fun clearAll()
}
