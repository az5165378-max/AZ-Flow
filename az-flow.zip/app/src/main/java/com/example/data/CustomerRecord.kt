package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "customer_records")
data class CustomerRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val phone1: String = "",
    val phone2: String = "",
    val phone3: String = "",
    val work: String = "",
    val amount: Double = 0.0,
    val fee: Double = 0.0,
    val profit: Double = 0.0,
    val status: String = STATUS_COMPLETED,
    val date: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    companion object {
        const val STATUS_COMPLETED = "مکمل ہو گیا"
        const val STATUS_IN_PROGRESS = "جاری ہے"
    }
}
