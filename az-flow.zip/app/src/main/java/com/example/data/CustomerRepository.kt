package com.example.data

import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CustomerRepository(private val dao: CustomerRecordDao) {

    val allRecords: Flow<List<CustomerRecord>> = dao.getAllRecords()

    suspend fun insert(record: CustomerRecord): Long {
        return dao.insertRecord(record)
    }

    suspend fun update(record: CustomerRecord) {
        dao.updateRecord(record)
    }

    suspend fun delete(record: CustomerRecord) {
        dao.deleteRecord(record)
    }

    suspend fun deleteById(id: Long) {
        dao.deleteRecordById(id)
    }

    suspend fun clearAll() {
        dao.clearAll()
    }

    suspend fun insertAll(records: List<CustomerRecord>) {
        dao.insertAll(records)
    }

    fun exportToJson(records: List<CustomerRecord>): String {
        val root = JSONObject()
        root.put("app", "AZ Flow")
        root.put("version", "14.0")
        root.put("backupDate", SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).format(Date()))

        val recordsArray = JSONArray()
        records.forEach { item ->
            val recordObj = JSONObject()
            recordObj.put("id", item.id)
            recordObj.put("name", item.name)
            recordObj.put("phone1", item.phone1)
            recordObj.put("phone2", item.phone2)
            recordObj.put("phone3", item.phone3)
            recordObj.put("work", item.work)
            recordObj.put("amount", item.amount)
            recordObj.put("fee", item.fee)
            recordObj.put("profit", item.profit)
            recordObj.put("status", item.status)
            recordObj.put("date", item.date)
            recordObj.put("createdAt", item.createdAt)
            recordsArray.put(recordObj)
        }
        root.put("records", recordsArray)
        return root.toString(2)
    }

    suspend fun importFromJson(jsonString: String): Result<Int> {
        return runCatching {
            val list = mutableListOf<CustomerRecord>()
            val trimmed = jsonString.trim()

            val recordsArray: JSONArray = if (trimmed.startsWith("{")) {
                val obj = JSONObject(trimmed)
                if (obj.has("records")) {
                    obj.getJSONArray("records")
                } else {
                    throw IllegalArgumentException("فائل میں 'records' ڈیٹا موجود نہیں ہے")
                }
            } else if (trimmed.startsWith("[")) {
                JSONArray(trimmed)
            } else {
                throw IllegalArgumentException("غلط فائل فارمیٹ")
            }

            for (i in 0 until recordsArray.length()) {
                val item = recordsArray.getJSONObject(i)
                val name = item.optString("name", "")
                if (name.isBlank()) continue

                val amount = item.optDouble("amount", 0.0)
                val fee = item.optDouble("fee", 0.0)
                val profit = if (item.has("profit")) item.optDouble("profit", amount - fee) else (amount - fee)
                val status = item.optString("status", CustomerRecord.STATUS_COMPLETED)
                val date = item.optString("date", SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date()))

                list.add(
                    CustomerRecord(
                        id = 0, // Auto-increment locally
                        name = name,
                        phone1 = item.optString("phone1", ""),
                        phone2 = item.optString("phone2", ""),
                        phone3 = item.optString("phone3", ""),
                        work = item.optString("work", ""),
                        amount = amount,
                        fee = fee,
                        profit = profit,
                        status = status,
                        date = date,
                        createdAt = item.optLong("createdAt", System.currentTimeMillis()),
                        updatedAt = System.currentTimeMillis()
                    )
                )
            }

            if (list.isNotEmpty()) {
                dao.insertAll(list)
            }
            list.size
        }
    }

    suspend fun loadSampleDemoData() {
        val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        val today = dateFormat.format(Date())
        val sampleList = listOf(
            CustomerRecord(
                name = "محمد عثمان",
                phone1 = "03001234567",
                phone2 = "03219876543",
                work = "آن لائن پاسپورٹ فارم اور فیس چالان",
                amount = 3500.0,
                fee = 1000.0,
                profit = 2500.0,
                status = CustomerRecord.STATUS_COMPLETED,
                date = today
            ),
            CustomerRecord(
                name = "بلال احمد ڈوگر",
                phone1 = "03125556677",
                work = "بینر اور فلیکس ڈیزائننگ",
                amount = 5000.0,
                fee = 1800.0,
                profit = 3200.0,
                status = CustomerRecord.STATUS_COMPLETED,
                date = today
            ),
            CustomerRecord(
                name = "چوہدری طارق محمود",
                phone1 = "03334445566",
                phone2 = "03007788990",
                work = "شناختی کارڈ تجدید اور فوٹو شوٹ",
                amount = 2200.0,
                fee = 600.0,
                profit = 1600.0,
                status = CustomerRecord.STATUS_IN_PROGRESS,
                date = today
            ),
            CustomerRecord(
                name = "کاشف علی ملک",
                phone1 = "03451239870",
                work = "انکم ٹیکس ریٹرن فائلنگ",
                amount = 8000.0,
                fee = 2500.0,
                profit = 5500.0,
                status = CustomerRecord.STATUS_IN_PROGRESS,
                date = today
            )
        )
        dao.insertAll(sampleList)
    }
}
